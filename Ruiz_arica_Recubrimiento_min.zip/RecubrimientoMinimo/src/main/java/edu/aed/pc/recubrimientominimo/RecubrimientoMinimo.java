package edu.aed.pc.recubrimientominimo;

import java.util.List;
import java.util.Scanner;
/*
Árboles de Recubrimiento de Grafos utilizando el algoritmo de Kruskal:
En este programa, creamos un grafo y agregamos aristas con pesos utilizando el método addEdge(). Luego, utilizamos el método findMinimumSpanningTree() para encontrar el árbol de recubrimiento mínimo utilizando el algoritmo de Kruskal. El árbol de recubrimiento mínimo se almacena en una lista de objetos Edge, donde cada objeto Edge representa una arista en el árbol.
Finalmente, imprimimos las aristas del árbol de recubrimiento mínimo.
*/

public class RecubrimientoMinimo {

    public static void main(String[] args) {
         Scanner scr = new Scanner(System.in);
         int vertices = 19;//definir la cantidad de vertices
         int test;
         Graph graph = new Graph(vertices); //creando el grafo de la clase Graph
         grafo1 g = new grafo1(vertices);//creando el grafo de la clase Graph
//Añadiendo los pesos graph y g
        
        graph.addEdge(0, 1, 20);
        graph.addEdge(0, 2, 10);
	graph.addEdge(0, 3, 14);
        graph.addEdge(1, 3, 15);
        graph.addEdge(1, 4, 17);
	graph.addEdge(1, 6, 18);
        graph.addEdge(1, 8, 10);
        graph.addEdge(2, 5, 9);
        graph.addEdge(3, 5, 6);
	graph.addEdge(3, 7, 18);
	graph.addEdge(3, 8, 11);
        graph.addEdge(4, 5, 6);
	graph.addEdge(5, 10, 14);
        graph.addEdge(5, 11, 11);
        graph.addEdge(6, 8, 11);
        graph.addEdge(7, 10, 16);
        graph.addEdge(7, 9, 9);
	graph.addEdge(8, 9, 7);
        graph.addEdge(9, 15, 16);
        graph.addEdge(10, 15, 8);
        graph.addEdge(10, 16, 15);
        graph.addEdge(10, 12, 10);
	graph.addEdge(11, 13, 19);
        graph.addEdge(11, 12, 9);
        graph.addEdge(12, 13, 13);
        graph.addEdge(12, 17, 12);
        graph.addEdge(13, 17, 9);
	graph.addEdge(13, 14, 9);
        graph.addEdge(14, 18, 22);
        graph.addEdge(17, 18, 4);
        graph.addEdge(16, 17, 13);
        
        
     
        g.addEdge(0, 1, 20);
        g.addEdge(0, 2, 10);
	g.addEdge(0, 3, 14);
        g.addEdge(1, 3, 15);
        g.addEdge(1, 4, 17);
	g.addEdge(1, 6, 18);
        g.addEdge(1, 8, 10);
        g.addEdge(2, 5, 9);
        g.addEdge(3, 5, 6);
	g.addEdge(3, 7, 18);
	g.addEdge(3, 8, 11);
        g.addEdge(4, 5, 6);
	g.addEdge(5, 10, 14);
        g.addEdge(5, 11, 11);
        g.addEdge(6, 8, 11);
        g.addEdge(7, 10, 16);
        g.addEdge(7, 9, 9);
	g.addEdge(8, 9, 7);
        g.addEdge(9, 15, 16);
        g.addEdge(10, 15, 8);
        g.addEdge(10, 16, 15);
        g.addEdge(10, 12, 10);
	g.addEdge(11, 13, 19);
        g.addEdge(11, 12, 9);
        g.addEdge(12, 13, 13);
        g.addEdge(12, 17, 12);
        g.addEdge(13, 17, 9);
	g.addEdge(13, 14, 9);
        g.addEdge(14, 18, 22);
        g.addEdge(17, 18, 4);
        g.addEdge(16, 17, 13);
        System.out.println("Algoritmo de recubrimiento minimo (Aplicacion)");
        System.out.println("Seleccione el algoritmo por el cual quiere que sea resuelto el problema");
        System.out.println("1)Algoritmo de kruskal");
        System.out.println("2)Algoritmo de Prim");
        test = scr.nextInt();
        if(test==1){
            //crear una lista de objetio tipo arista con el sgt metodo   
             List<Graph.Edge> minimumSpanningTree = graph.findMinimumSpanningTree();
            System.out.println("Minimum Spanning Tree:");
            for (Graph.Edge edge : minimumSpanningTree) {
               System.out.println(edge.getSource() + " -- " + edge.getDestination() + " : " + edge.getWeight());
            }
        }else{
            g.mst();
        }
        graph =null;
        g=null;
    }
}
