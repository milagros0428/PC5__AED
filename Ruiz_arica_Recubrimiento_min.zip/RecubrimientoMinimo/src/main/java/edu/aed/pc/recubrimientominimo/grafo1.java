/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.aed.pc.recubrimientominimo;

 public class grafo1{
     long startTime = System.currentTimeMillis();
        int vertices;
        int mat[][];
   
        public grafo1(int vertices){
            this.vertices = vertices;
            mat = new int[vertices][vertices];
        }
        public void addEdge(int ori, int des, int peso) {
            mat[ori][des]=peso;
            mat[des][ori]=peso;
        }
        class Resultado {
            int padre;
            int peso;
        }
        int minVert( boolean [] mst, int [] pesos){
            int minPeso = Integer.MAX_VALUE;
            int vertice = -1;

            for (int i = 0; i < vertices; i++) {
        if (!mst[i] && minPeso > pesos[i]) {
            minPeso = pesos[i];
            vertice = i;
        }
    }

    if (vertice == -1) {
        // No se encontró un vértice válido, puedes manejarlo como desees
        // Por ejemplo, lanzar una excepción o imprimir un mensaje de error
        throw new IllegalStateException("No hay vértices disponibles para seleccionar");
    }
            return vertice;
        }
        public void mst() {
            boolean [] mst = new boolean[vertices];
            int [] pesos = new int [vertices];
            Resultado [] resultado = new Resultado [vertices];

            for (int i = 0; i < vertices; i++) {
                pesos[i] = Integer.MAX_VALUE;
                resultado[i] = new Resultado();
            }
            pesos[0]=0;
            resultado[0].padre=-1;
            for (int i = 0; i < vertices; i++) {
                int vertice = minVert(mst, pesos);
                mst[vertice]= true;
                for (int j = 0; j < vertices; j++) {
                    if (mat[vertice][j]>0) {
                        if (mst[j]==false && mat[vertice][j]< pesos[j]) {
                            pesos[j] = mat[vertice][j];
                            resultado[j].padre=vertice;
                            resultado[j].peso = pesos[j];
                        }                        
                    }                                        
                }                
            }
            printMst(resultado);
        }
        public void printMst( Resultado [] resultado ) {
            int total_coste_min = 0;
            System.out.println("Arbol de recubrimiento minimo");
            
            for (int i = 1; i < vertices; i++) {
                System.out.println("Arista " + i + " - " + resultado[i].padre + " peso: " + resultado[i].peso);
                total_coste_min +=resultado[i].peso;
            }
            System.out.println("Coste min total = " + total_coste_min);
            long endTime = System.currentTimeMillis();
        double duration = (endTime - startTime)/1000.0;

        System.out.println("Tiempo de ejecución: " + duration + " milisegundos");
        
        }
    }
