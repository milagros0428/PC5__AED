/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edu.aed.pc.recubrimientominimo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Graph {
    //declaracion de variables
    long startTime = System.currentTimeMillis();
    int camino=0;
    private int vertices;
    private List<Edge> edges;

    public Graph(int vertices) {
        this.vertices = vertices;
        this.edges = new ArrayList<>();
    }

    public void addEdge(int source, int destination, int weight) {//metodo añadir vertice
        Edge edge = new Edge(source, destination, weight);//(vert_origen,vert_destino,peso)
        edges.add(edge);
    }

    public List<Edge> findMinimumSpanningTree() {//metodo hallar el arbol de expansion minima
        List<Edge> minimumSpanningTree = new ArrayList<>();//crear una lista de tipo aristas 

        //Ordenar aristas en orden ascendente por peso
        Collections.sort(edges, Comparator.comparingInt(Edge::getWeight));
         for (Edge edge : edges) {
            System.out.println(edge.getSource() + " --(" + edge.getWeight() + ")-- " + edge.getDestination());
        }
        // Create a parent array for disjoint setss
        //Crear una matriz principal para conjuntos disjuntos
        int[] parent = new int[vertices];
        for (int i = 0; i < vertices; i++) {
            parent[i] = i;
        }

        int edgesAdded = 0;
        int index = 0;
        //Iterar a través de todos las aristas y agregar al árbol de expansión mínimo si no forma un ciclo
        while (edgesAdded < vertices - 1) {
            Edge edge = edges.get(index++);
         //   System.out.println("aristaaa "+edge.getSource());
            int sourceParent = find(parent, edge.getSource());
         //   System.out.println("padre origen "+ sourceParent);
            int destinationParent = find(parent, edge.getDestination());
         //   System.out.println("destino "+ destinationParent);
            if (sourceParent != destinationParent) {
                minimumSpanningTree.add(edge);
           //     System.out.println("union");
                union(parent, sourceParent, destinationParent);
                camino= camino + edge.getWeight();
                edgesAdded++;
            }
          
        }
        long endTime = System.currentTimeMillis();
        double duration = (endTime - startTime)/1000.0;

        System.out.println("Tiempo de ejecución: " + duration + " milisegundos");
        System.out.println("Camino total "+ camino);
        return minimumSpanningTree;
        
    }

    private int find(int[] parent, int vertex) {
        if (parent[vertex] != vertex) {
            parent[vertex] = find(parent, parent[vertex]);
        }
        return parent[vertex];
    }

    private void union(int[] parent, int source, int destination) {
        parent[source] = destination;
    }

    static class Edge {
        private int source;
        private int destination;
        private int weight;

        public Edge(int source, int destination, int weight) {
            this.source = source;
            this.destination = destination;
            this.weight = weight;
        }

        public int getSource() {
            return source;
        }

        public int getDestination() {
            return destination;
        }

        public int getWeight() {
            return weight;
        }
    }

 
}
